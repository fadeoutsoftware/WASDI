/*
 * Copyright (c) Fadeout Software 2020. Marco Menapace
 *
 */

package it.fadeout.utils.zipextractor;

import java.io.IOException;

public class Main {

    /* Create an utils that let the user unzip an archive with some
    predefined logics:
    - The total size must be under a certain Threshold in terms of disk usage
    - Also the number of entries must be under a certain threshold
    - In some parts of WASDI some operation are done using the extension of the files so
    checks if it's possible to reproduce such behaviour on a generics class
    THEN
    Let JunitWork on your local Machine
    Write some tests and share them across the team to validate the new procedures.
    Embed everything in public static class as utils
          ------------ NEW REQUIREMENTS ------------
    - extract in a temp dir {temp-[SecureRand().nextInt()]} Java.util.UUID
    IF everything is ok {
    copy file in dest dir, overwrite same name files
    delete temp directory
    }
    else
    {
    delete temp directory
    throw an exception
    }
    */

    /**
     * Useless main method
     *
     * @param args args of main. what else
     */
    public static void main(String[] args) {

        try {
            new ZipExtractor().unzip("./extractionFolder/test.zip", "./extractionFolder/");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
